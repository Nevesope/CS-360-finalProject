package com.example.projectpages;

import android.app.Activity;
import android.os.Bundle;


import androidx.annotation.Nullable;

public class contactpage extends Activity {
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.contact_page);
    }
}
